import React from "react";
  
// Simple rendering with fragment syntax
class Fragment extends React.Component {
  render() {
    return (
      <React.Fragment>
        <h2>God is great..!!</h2>
  
        <p>Health is wealth.</p>
      </React.Fragment>
    );
  }
}
  
export default Fragment;