import React from "react";
function CountryList(props) {
    return (
      <dl>
        {props.countries.map(country => (
          // Without the `key`, React will fire a key warning in console.
          <React.Fragment key={country.id}>
            <dt>{country.name}</dt>
            <dd>{country.capital}</dd>
          </React.Fragment>
        ))}
      </dl>
    );
  
}

export default CountryList;