import React from "react";
  
// Shorthand fragment syntax - <></>
class ShorthandFragment extends React.Component {
  render() {
    return (
      <>
        <h2>God is great..!!</h2>
  
        <p>Health is wealth.</p>
      </>
    );
  }
}
  
export default ShorthandFragment;