import React, {Component, component} from 'react';
import hoc from './component/hoc';
import './App.css';

class App extends Component {
  render() {
    return(
      <div>
        <h2>HOC</h2>
      </div>
    )
  }
}

App = hoc(App)

export default App;
