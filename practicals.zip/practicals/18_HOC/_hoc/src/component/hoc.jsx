import React, { Component } from "react";

export default function hoc(HComponent) {
  return class extends Component {
    render() {
      return (
        <>
          <div>hoc</div>
          <HComponent></HComponent>
        </>
      );
    }
  }
}
