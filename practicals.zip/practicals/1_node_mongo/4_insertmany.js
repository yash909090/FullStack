var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("class");
  var myobj = [
    { name: 'Shubham', address: 'Chhalisgaon, Maharashtra, INDIA.'},
    { name: 'Darshan', address: 'Junagadh, Gujarat, INDIA.'},
    { name: 'Vishnu', address: 'Chhalisgaon, Maharashtra, INDIA.'}
  ];
  dbo.collection("student").insertMany(myobj, function(err, res) {
    if (err) throw err;
    console.log("Number of documents inserted: " + res.insertedCount);
    db.close();
  });
});