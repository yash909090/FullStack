import React from "react";
class Myfirstclass extends React.Component{
    render(){
        return <h1>This is class componant.</h1>
    }
}
export default Myfirstclass;