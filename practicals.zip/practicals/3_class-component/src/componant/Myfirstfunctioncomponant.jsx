import ReactDOM from "react-dom";

function Myfirstfunction(){
    return <h1>Hello Everyone...!!! My first function componant.</h1>;
}
ReactDOM.render(<Myfirstfunction/>, document.getElementById('root'));
export default Myfirstfunction;