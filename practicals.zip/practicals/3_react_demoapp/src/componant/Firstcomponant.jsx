import React from "react";


function Firstcomponant(){
    return(
    <h3>First Componant</h3>
    );
}
export default Firstcomponant;