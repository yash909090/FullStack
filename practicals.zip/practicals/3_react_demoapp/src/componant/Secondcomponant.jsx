import React from "react";
import Secondcomponantchild from "./Secondcomponantchild";

function Secondcomponant(){
    return(
        <div>
        <h3>This is Second Componant.</h3>
        <Secondcomponantchild/>
        </div>
          
    );
}
export default Secondcomponant;