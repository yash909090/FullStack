import React from "react";

function Thirdcomponant(){
    return(
        <h3>This is Third Componant.</h3>
    );
}
export default Thirdcomponant;