import logo from './logo.svg';
import './App.css';

import { BrowserRouter,Routes, Route } from 'react-router-dom';
import FirstComponent from './componant/FirstComponent';
import SecondComponent from './componant/SecondComponent';
import ThirdComponent from './componant/ThirdComponent';
import FourthComponent from './componant/FourthComponent';
import NavBar from './componant/NavBar';

function App() {
  return (
  // <>
  // <FirstComponent></FirstComponent>
  // <SecondComponent></SecondComponent>
  // </>
  <BrowserRouter>
    <NavBar/>
    <Routes>
      <Route path='/' element={<FirstComponent/>}></Route>
      <Route path='/SecondComponent' element={<SecondComponent/>}></Route>
      <Route path='/ThirdComponent' element={<ThirdComponent/>}></Route>
      <Route path='/FourthComponent' element={<FourthComponent/>}></Route>

    </Routes>
  </BrowserRouter>
  );
}

export default App;
