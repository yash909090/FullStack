import React from "react";
class SecondComponent extends React.Component{
    render(){
        const internalcss = {fontSize:'75px', color:'blue'}
        return <h1 style={internalcss}>Second Componant.</h1>
    }
}
export default SecondComponent;