import React from "react";
import '../css/demo.css';
class ThirdComponent extends React.Component{
    render(){
        return <h1 className="ThirdComponentExternalCSS">Third Component.</h1>
    }
}
export default ThirdComponent;