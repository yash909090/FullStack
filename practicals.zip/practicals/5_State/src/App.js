import './App.css';
// import Person from './componant/ClassComponent';
// import Person from './componant/UpdateClassComponent';
import UseStateFun from './componant/UseStateFun';
function App() {
  return (
    // <Person/>
   <UseStateFun/>
  );
}

export default App;
