import './App.css';

import PersonDefaultDemo from './componant/DefaultProp';

// import ArrayProps from './componant/ArrayAsProps';

// import PersonBasicDetails from './Components/PersonBasicDetails_FunctionComponent'

// import PersonJobDetails from './Components/PersonJobDetails_FunctionComponent'

// import ParentSampleRenderProps from './Components/RenderPropDemo'

// import PersonCompany from './Components/RenderPropAdvanceDemoWithStateAndSubChild'

// import GrandParent from './Components/Live';

function App() {
  return (
    // Default Prop - Class Componet with Props
    <div >
      <PersonDefaultDemo></PersonDefaultDemo>
      <PersonDefaultDemo name="Yash Kakdiya" gender="Male"></PersonDefaultDemo>
      <PersonDefaultDemo name="Darshan Savani" gender="Male"></PersonDefaultDemo>
      <PersonDefaultDemo name="Shubham Chaudhri" gender="Male"></PersonDefaultDemo>
    </div>

    // Array as Props
    // <ArrayProps></ArrayProps>

    // Functional Component Prop
    // <div>
    //   <PersonBasicDetails></PersonBasicDetails>
    // </div>

    // Render Props
    // <ParentSampleRenderProps/>

    // Render Props
    // <PersonCompany/>

    // <GrandParent/>
    
  );
}

export default App;
