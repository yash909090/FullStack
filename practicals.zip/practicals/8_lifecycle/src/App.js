import './App.css';
import Lifecycle from './Components/LifeCycle';

function App(){
  return (
    <>
      <h1>God is Great.</h1>
     <Lifecycle></Lifecycle>
    </>
    
  )
}
export default App;