import React from "react";
import  ReactDOM from "react-dom";

class Lifecycle extends React.Component{
    constructor(props)
    {
        super(props);
        this.state={ Demo : "god is Great..!!"};
    }


    componentWillMount()
    {
        alert("componentWillMount() Called.");
        console.log("componentWillMount() called.");
    }

    componentDidMount()
    {
        alert("comonentDidMount() Called.");
        console.log("componentDidMount() called.");
    }

    changeState()
    {
        this.setState({ Demo : "Time Is Money..!!"});
        console.log(this.state.Demo);
    }

    render()
    {
        return(
            <div>
                <h1>{this.state.Demo}</h1>
                <h2>
                    <a onClick={this.changeState.bind(this)}>Click Me To Change the State.</a>
                </h2>
            </div>
        );
    }

    shouldComponentUpdate(nextProps, nextState)
    {
        alert("shouldComponentUpdate() Called");
        console.log("shouldComponentUpdate() Called");
        return true;
    }

    componentWillUpdate()
    {
        alert("componentWillUpdate() Called.");
        console.log("componentWillUpdate() Called.");
    }

    componentDidUpdate()
    {
        alert("componentDidUpdate() Called");
        console.log("componentDidUpdate() Called.");
    }
}

ReactDOM.render(<Lifecycle/>,document.getElementById('root'));

export default Lifecycle;