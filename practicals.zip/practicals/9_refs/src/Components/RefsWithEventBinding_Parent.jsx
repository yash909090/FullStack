import React, {useRef} from 'react'
import ChildComp from './RefsWithEventBinding_Child';

// Here Refs are created using React.createRef() and attached to React elements via the ref attribute. 
// Refs are commonly assigned to an instance property when a component is constructed so they can be referenced throughout the component.
// When a ref is passed to an element in render, a reference to the node becomes accessible at the current attribute of the ref.
// The value of the ref differs depending on the type of the node:
    // 1) When the ref attribute is used on an HTML element, the ref created in the constructor with React.createRef() receives the underlying DOM element as its current property.
    // 2) When the ref attribute is used on a custom class component, the ref object receives the mounted instance of the component as its current.
    // 3) You may not use the ref attribute on function components because they don’t have instances.
    
function ParentFunctionComp() {
  const childCompRef = useRef()
  return (
    <div>
      <button onClick={() => childCompRef.current.showAlert()}>Click Me</button>
      <ChildComp ref={childCompRef} />
      
    </div>
  )
}
export default ParentFunctionComp;

