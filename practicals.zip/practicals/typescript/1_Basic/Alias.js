var mes;
mes = "We Are Alien For Other World.";
console.log(mes);
var input;
input = 1; // valid
input = "We Are Alien For Other World."; // valid
console.log(input);
