type chars = string;
let mes: chars;
mes="We Are Alien For Other World.";
console.log(mes);

type alphanumeric = string | number;
let input: alphanumeric;
input = 1; // valid
input = "We Are Alien For Other World."; // valid
console.log(input);