function showFun(id, nm) {
    console.log("Id = " + id + " Name=" + nm);
}
showFun(1, "Yash Kakadiya");
var person;
person = {
    id: 1,
    nm: "Yash Kakadiya"
};
console.log(person.id + " " + person.nm);
function sum(n1, n2) {
    return n1 + n2;
}
var Addition = sum(10, 20);
console.log("Add: " + Addition);
