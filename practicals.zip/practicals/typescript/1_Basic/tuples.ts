var demoTuple = [1,"Yash","Kakadiya"]; 
console.log("Count before push "+demoTuple.length)   

demoTuple.push(2)                                  
console.log("Count after push "+demoTuple.length) 
console.log("Count before pop "+demoTuple.length) 

console.log(demoTuple.pop()+" popped from the tuple") 
console.log("Count after pop "+demoTuple.length)