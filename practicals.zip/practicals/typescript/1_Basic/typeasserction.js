var empCode = 111;
var employeeCode = empCode;
console.log("Type is:" + typeof (employeeCode));
var empCode2 = 111;
var employeeCode2 = empCode;
console.log("Type is:" + typeof (employeeCode2));
var p = {};
p.code = 1;
p.name = "Yash";
