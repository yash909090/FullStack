var num;
num = 0;
var arr = [0, 1, null, 'Hi', new Date()];
console.log(typeof arr);
console.log(typeof arr[0]);
console.log(typeof arr[2]);
console.log(typeof arr[3]);
console.log(typeof arr[4]);
