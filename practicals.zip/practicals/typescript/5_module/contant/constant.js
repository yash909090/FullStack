"use strict";
exports.__esModule = true;
exports.Constant = void 0;
var Constant = /** @class */ (function () {
    function Constant() {
    }
    Constant.EmailReg = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    Constant.ZipReg = /^[0-9]+$/;
    return Constant;
}());
exports.Constant = Constant;
