export class Constant{
    public static EmailReg=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    public static ZipReg=/^[0-9] +$/;
    public static FullNameRegEx = /^([a-zA-Z] {2,40})$/;
}