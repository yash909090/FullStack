export interface I1{
    ValidEmail(s:string):boolean;
    ValidZip(s:string):boolean;
    ValidFullName(s:string):boolean;
    // isValid(s:string, Regex, min?: number, max?: number):boolean
}