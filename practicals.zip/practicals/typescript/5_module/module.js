"use strict";
exports.__esModule = true;
var validator_1 = require("./validator/validator");
var Email = "xyz@gmail.com";
var zipcode = "444444";
var Vlaid = new validator_1.Validatorcls();
console.log(Vlaid.ValidEmail(Email));
console.log(Vlaid.ValidZip(zipcode));
// console.log(resultemail)
// console.log(resultzip)
