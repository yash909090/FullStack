import { Validatorcls } from "./validator/validator";

let Email="xyz@gmail.com"
let zipcode="444444"
let Fullname="yashkakadiya"

const Vlaid=new Validatorcls();

console.log(Vlaid.ValidEmail(Email))
console.log(Vlaid.ValidZip(zipcode))
console.log(Vlaid.ValidFullName(Fullname))

// console.log(resultemail)
// console.log(resultzip)

