"use strict";
exports.__esModule = true;
exports.Validatorcls = void 0;
var constant_1 = require("../contant/constant");
var Validatorcls = /** @class */ (function () {
    function Validatorcls() {
    }
    Validatorcls.prototype.ValidEmail = function (s) {
        return constant_1.Constant.EmailReg.test(s);
    };
    Validatorcls.prototype.ValidZip = function (s) {
        return s.length >= 6 && constant_1.Constant.ZipReg.test(s);
    };
    return Validatorcls;
}());
exports.Validatorcls = Validatorcls;
