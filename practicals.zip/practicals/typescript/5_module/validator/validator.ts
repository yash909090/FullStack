import {I1} from "../interface/interface"
import {Constant} from '../contant/constant'


class Validatorcls implements I1{
    ValidEmail(s:string):boolean{
        return Constant.EmailReg.test(s);
    }

    ValidZip(s: string): boolean {
        return  Constant.ZipReg.test(s);
    }
    ValidFullName(s: string): boolean {
        return s.length===6 && Constant.FullNameRegEx.test(s);
    }
}
 /*
 class Validatorcls implements I1{
    isValid(s:string, Regex, min?: number, max?: number):boolean{
        return Constant..test(s);
    }
    else if(max==undifined){
        max= min
    }
    return s.length>=min && s.length<=max && Regex.test(s)
}
*/
export {Validatorcls}